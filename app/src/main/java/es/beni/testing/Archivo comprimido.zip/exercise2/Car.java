package es.beni.testing.exercise2;

public interface Car {
    Engine getEngine();

    int getColor();

    Manufacter getManufacturer();
}
