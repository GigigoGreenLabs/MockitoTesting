package es.beni.testing.exercise4.interfaces;

import es.beni.testing.exercise4.entities.Crm;

public interface AuthenticationService {
    void saveUser(Crm crm);
}
