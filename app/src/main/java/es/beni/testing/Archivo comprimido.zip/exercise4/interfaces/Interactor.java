package es.beni.testing.exercise4.interfaces;

public interface Interactor<T> {
}
