package es.beni.testing.exercise2;

public interface Engine {
    int getNbOfCylinders();
}
