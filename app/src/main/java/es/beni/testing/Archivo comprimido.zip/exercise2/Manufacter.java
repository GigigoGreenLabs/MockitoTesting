package es.beni.testing.exercise2;

public interface Manufacter {
    String getName();
}
